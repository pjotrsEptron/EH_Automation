﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using EveryHairTestScripts.utils;
using static EveryHairTestScripts.utils.Find;

namespace EveryHairTestScripts
{
    public class addReseller : SetupSteps

    {

        public IWebDriver driver;

  

        public void openResellerPage()
        {
            // click settings
            find(By.XPath("/html/body/div[1]/div/div[1]/nav/div/ul/li[12]/a")).Click();


            Thread.Sleep(3000);
            // click Resellers
            find(By.XPath("/html/body/div/div/div[1]/nav/div/ul/li[12]/ul/li[3]/a/span/span")).Click();

            // check that resellers page is opened

        }
        public void addNewReseller()
        {

            // generator of random string
            checkTitle = Generate.RandomString(4);

            // click add new reseller button
            find(By.XPath("/html/body/div/div/div[2]/div[2]/div[2]/div/div/div/div[1]/div/a/span/span")).Click();

            // Clear Name if exists
            find(By.XPath("/html/body/div/div/div[2]/div[2]/div[2]/div/div/div/div/div/div[1]/div/fieldset/form/div[1]/div/input")).Clear();

            // Type Name
            find(By.XPath("/html/body/div/div/div[2]/div[2]/div[2]/div/div/div/div/div/div[1]/div/fieldset/form/div[1]/div/input")).SendKeys(checkTitle);

            // Clear Name
            find(By.XPath("/html/body/div/div/div[2]/div[2]/div[2]/div/div/div/div/div/div[1]/div/fieldset/form/div[2]/div/input")).Clear();

            // Type Email
            find(By.XPath("/html/body/div/div/div[2]/div[2]/div[2]/div/div/div/div/div/div[1]/div/fieldset/form/div[2]/div/input")).SendKeys("automated@eptron.eu");

            // set countries (belgium)
            find(By.XPath("/html/body/div/div/div[2]/div[2]/div[2]/div/div/div/div/div/div[1]/div/fieldset/form/div[5]/div/div/div/input")).Click();

            find(By.XPath("/html/body/div/div/div[2]/div[2]/div[2]/div/div/div/div/div/div[1]/div/fieldset/form/div[5]/div/div/ul/li/div[3]/a/div")).Click();

            // set language
            find(By.XPath("/html/body/div/div/div[2]/div[2]/div[2]/div/div/div/div/div/div[1]/div/fieldset/form/div[6]/div/div/div/input")).Click();
            find(By.XPath("/html/body/div/div/div[2]/div[2]/div[2]/div/div/div/div/div/div[1]/div/fieldset/form/div[6]/div/div/ul/li/div[3]/a")).Click(); // set as EN


            // set def lang
            find(By.XPath("/html/body/div/div/div[2]/div[2]/div[2]/div/div/div/div/div/div[1]/div/fieldset/form/div[7]/div/div/select")).Click();
            find(By.XPath("/html/body/div/div/div[2]/div[2]/div[2]/div/div/div/div/div/div[1]/div/fieldset/form/div[7]/div/div/select/option[2]")).Click();

            // drop coursor

            find(By.XPath("/html/body/div/div/div[2]/div[2]/div[2]/div/div/div/div/div/div[1]/div/fieldset/form/div[8]/div/p")).Click();


        

        }

        public void pressSaveButtonReseller()
        {

            // press save
            find(By.XPath("//div[@id='page-wrapper']/div[2]/div[2]/div/div/div/div/div/div/div/fieldset/form/div[10]/div/button")).Click();
            Thread.Sleep(3000);
        }

        public void checkResellerCreated()
        {

          
            find(By.XPath("/html/body/div/div/div[2]/div[2]/div[1]/div[1]/button")).Click(); // click Back Button
          
            
            find(By.XPath("/html/body/div/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/div[1]/div[2]/div/label/input")).SendKeys(checkTitle);

            //WebDriverWait wait01 = new WebDriverWait(driver, new TimeSpan(0, 0, 15));
            //wait01.Until(ExpectedConditions.TextToBePresentInElement(By.XPath("/html/body/div/div/div[2]/div[2]/div[2]/div/div/div/div[2]/div/table/tbody/tr/td[2]"), checkTitle);

        }
    }
}


